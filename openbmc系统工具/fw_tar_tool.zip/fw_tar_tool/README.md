# phosphor-bmc-code-mgmt
Phosphor BMC Code Management provides a set of system software management
applications. More information can be found at
[Software Architecture](https://github.com/openbmc/phosphor-dbus-interfaces/blob/master/yaml/xyz/openbmc_project/Software/README.md)

## To Build
To build this package, do the following steps:

1. `meson build`
2. `ninja -C build`

To clean the repository run `rm -r build`.


# Add for Cunjin.Tao

## Get firmware tar package
Rename your BIOS to bios.bin
Rename your CPLD to cpld.jed
cmd: gen-fw-tar -m palos -t bios -v test bios.bin
	will get obmc-host.tar.gz
cmd: gen-fw-tar -m palos -t cpld -v test cpld.jed
	will get obmc-cpld.tar.gz
try: gen-fw-tar -h
	for more info
